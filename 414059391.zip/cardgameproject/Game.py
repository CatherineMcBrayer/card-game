#############
# author: Lily McBrayer
# date: 5/17/2026
# description: The GUI for the card game
############

# imports (i use tkinter for this gui)

from tkinter import *
from tkinter import messagebox # used for pop up boxes
from Cards import Deck

class GUI:
    def __init__(self):

        # window

        self.window = Tk()
        self.window.title("CSC Card Game")
        self.window.configure(bg="tomato2")
        self.window.geometry("900x600")

        # deck

        self.deck = Deck()
        self.deck.shuffle()
        self.deck.shuffle()

        # title label

        self.title_label = Label(self.window, text="CSC Card Game", font=("Courier", 24, "bold"), bg="tomato2", fg="white")

        self.title_label.pack(pady=20)

        #frame for the cards

        self.cards_frame = Frame(self.window, bg="tomato2")
        self.cards_frame.pack(pady=20)

        # the computers side

        self.computer_frame = Frame(self.cards_frame, bg="tomato2")
        self.computer_frame.grid(row=0, column=0, padx=50)

        self.computer_label = Label(self.computer_frame, text="Computer", font=("Courier", 18), bg="tomato2", fg="white")
        self.computer_label.pack()

        self.computer_image_label = Label(self.computer_frame, bg="tomato2")
        self.computer_image_label.pack()

        # the players side
        self.player_frame = Frame(self.cards_frame, bg="tomato2")
        self.player_frame.grid(row=0, column=1, padx=50)

        self.player_label = Label(self.player_frame, text="Player", font=("Courier", 18), bg="tomato2", fg="white")
        self.player_label.pack()

        self.player_image_label = Label(self.player_frame, bg="tomato2")
        self.player_image_label.pack()

        # results

        self.result_label = Label(self.window, text="Press Play to Start!", font=("Courier", 18), bg="tomato2", fg="gray10")
        self.result_label.pack(pady=20)

        # cards remaining

        self.cards_left_label = Label(self.window, text=f"Cards Remaining: {self.deck.size()}", font=("Courier", 16), bg="tomato2", fg="white")
        self.cards_left_label.pack()

        # frame for buttons

        self.button_frame = Frame(self.window, bg="tomato2")
        self.button_frame.pack(side=BOTTOM, pady=30)

        # play button

        self.play_button = Button(self.button_frame, text="Play", font=("Courier", 16), width=10, command=self.play)
        self.play_button.grid(row=0, column=0, padx=20)

        # restart button

        self.restart_button = Button(self.button_frame, text="Restart", font=("Courier", 16), width=10, command=self.restart)
        self.restart_button.grid(row=0, column=1, padx=20)

        # quit button

        self.quit_button = Button(self.button_frame, text="Quit", font=("Courier", 16), width=10, command=self.window.destroy)
        self.quit_button.grid(row=0, column=2, padx=20)

        #start program

        self.window.mainloop()

    def play(self):

        #close if no cards
        if self.deck.size() < 2:
            messagebox.showinfo("Game Over!!", "There's no more cards in the deck!")
            self.window.destroy()

        # draw cards
        player_card = self.deck.draw()
        computer_card = self.deck.draw()

        #load images
        player_image = PhotoImage(file=player_card.imagefile)
        computer_image = PhotoImage(file=computer_card.imagefile)

        # make the images smaller so the buttons stop DISAPPEARING

        player_image = player_image.subsample(2, 2)
        computer_image = computer_image.subsample(2, 2)

        # keep references
        self.player_image_label.image = player_image
        self.computer_image_label.image = computer_image

        # display images

        self.player_image_label.config(image=player_image)
        self.computer_image_label.config(image=computer_image)

        # figure out who wins!

        if player_card > computer_card:
            result = "You won this round!"
        elif player_card < computer_card:
            result = "Sorry, the computer won this round!"
        else:
            result = "You tied!"

        # update labels
        self.result_label.config(text=result)
        self.cards_left_label.config(text=f"Cards Remaining: {self.deck.size()}")

    def restart(self):

        # remake the deck, shuffles twice
        self.deck = Deck()
        self.deck.shuffle()
        self.deck.shuffle()

        # reset screen
        self.player_image_label.config(image="")
        self.computer_image_label.config(image="")

        self.result_label.config(text="Press Play to Start!!")
        self.cards_left_label.config(text=f"Cards Remaining: {self.deck.size()}")

# starts game
GUI()

        
    
