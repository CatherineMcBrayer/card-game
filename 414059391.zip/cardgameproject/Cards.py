#####################################################################
# author: Lily McBrayer     
# date: 5/17/2026
# description: Improving the card game!
#####################################################################

# import the shuffle and seed functions from the random library.
import random
# NEW FOR PROG 7
import os


# set the seed
random.seed(9876543210)

# define the possible suits that the cards can have using a list.
POSSIBLESUITS = ["clubs", "diamonds", "hearts", "spades"]

class Card:

    # define the possible suits that the cards can have using a list.
    POSSIBLESUITS = ["clubs", "diamonds", "hearts", "spades"]

    def __init__(self, number, suit):
        self.number = number
        self.suit = suit

# mutators and accesors for number and suit
        
    @property
    def number(self):
        return self._number

# gives number a default value to default to if the value falls outside the range
    @number.setter
    def number(self, value):
        if isinstance(value, int) and 2 <= value <= 10:
            self._number = value
        else:
            self._number = 2

    @property
    def suit(self):
        return self._suit

# gives suit a default suit to default to if the suit doesnt
# fall within the possible suits list

    @suit.setter
    def suit(self, value):
        if value in POSSIBLESUITS:
            self._suit = value
        else:
            self._suit = "clubs"
            
# overloading the operators

    def __eq__(self, other):
        if isinstance(other, Card):
            return self.number == other.number
        return False

    def __lt__(self, other):
        if isinstance(other, Card):
            return self.number < other.number
        return NotImplemented

    def __gt__(self, other):
        if isinstance(other, Card):
            return self.number > other.number
        return NotImplemented

# string function in order to print each card

    def __str__(self):
        return f"{self.number} of {self.suit}"

# hash function pulled from the instructions

    def __hash__(self):
        return hash((self.number, self.suit))

class Deck:
    def __init__(self):
        # modified for prog 7
        self.cards = [PictureCard(n, s)
                      for n in range(2,11)
                      for s in POSSIBLESUITS]

# mutators and accessors for cards in the deck class
    @property
    def cards(self):
        return self._cards

    @cards.setter
    def cards(self, value):
        self._cards = value
        
# uses the shuffle from the imported random library to shuffle the cards

    def shuffle(self):
        random.shuffle(self._cards)
        
# returns the length of the list cards
    def size(self):
        return len(self._cards)

    def draw(self):
        if not self._cards:
            return None
        return self._cards.pop(0) #returns the first card (i had to look this up)

    def __str__(self):
        if not self._cards:
            return "[--empty--]"

        cards_str = ", ".join([str(card) for card in self._cards])
        return f"[{cards_str}, ]"

#NEW FOR PROG 7
class PictureCard(Card):
    def __init__(self, number, suit):
        super().__init__(number, suit)
        filename = f"images/{number}_of_{suit}.png"
        self.imagefile = filename
    # mutator and accessor for new class
    # mutator sets to default if file invalid
    @property
    def imagefile(self):
        return self._imagefile

    @imagefile.setter
    def imagefile(self, value):
        if os.path.isfile(value):
            self._imagefile = value
        else:
            self._imagefile = "images/default.png"
        


class Game:
    def __init__(self):
     #initializes deck and shuffles twice
        self.deck = Deck()
        self.deck.shuffle()
        self.deck.shuffle()
# mutator and accessor for the deck, no specific parameters
    @property
    def deck(self):
        return self._deck

    @deck.setter
    def deck(self, value):
        self._deck = value

    def start(self):
# start function begins the game and either directs user to play or to end
        print("The Game is Starting!")
        begin = input("Do you want to play? (yes/no): ").strip().lower()

        if begin == 'yes':
            self.play()
        else:
            self.end()
# end function ends the card game and announces deck state
    def end(self):
        print("\nSee you next time!")
        print("Here's the final state of the deck:")
        print(self._deck)

    def play(self):
        # game starts here, draws cards for player and computer
        if self._deck.size() >= 2:
            player_card = self.deck.draw()
            computer_card = self.deck.draw()

            print(f"\n You drew: {player_card}")
            print(f"The computer drew: {computer_card}")

            self.deck.shuffle()

        # checks to see who won and announces it to player. it does this through comparison

            if player_card > computer_card:
                print("You win this round!")
            elif player_card < computer_card:
                print("The computer won this time!")
            else:
                print("It's a tie!")

        # using user input, checks if user wants to play again or not
        # either ends or plays again

            again = input("Do you wanna play again? (yes/no)").strip().lower()

            if again == 'yes':
                self.play()
            else:
                self.end()
        else:
            print("Out of cards!")
            self.end()
        

            
